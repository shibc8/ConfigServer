package com.oreilly.integration;

public class PersonDirectoryService {

	public Person findNewPeople(){
		return new Person("Jan", "Doe");
	}
}
