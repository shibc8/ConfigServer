package com.oreilly.integration;

public interface EnhancedPrinterGateway {

	public void print(Person person);
	
	public String uppercase(Person person);
	
}
