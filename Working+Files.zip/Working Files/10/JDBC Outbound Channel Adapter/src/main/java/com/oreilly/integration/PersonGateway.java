package com.oreilly.integration;

public interface PersonGateway {

	public void save(Person person);
}
